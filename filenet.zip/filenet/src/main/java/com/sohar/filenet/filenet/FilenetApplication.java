package com.sohar.filenet.filenet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilenetApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilenetApplication.class, args);
	}

}
